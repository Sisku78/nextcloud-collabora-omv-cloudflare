# coolwsd.xml de Collabora
