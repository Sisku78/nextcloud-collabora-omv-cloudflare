# config.php de Nextcloud
