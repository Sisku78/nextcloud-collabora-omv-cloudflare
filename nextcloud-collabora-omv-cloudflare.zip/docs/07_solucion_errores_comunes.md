# Solución a errores comunes
