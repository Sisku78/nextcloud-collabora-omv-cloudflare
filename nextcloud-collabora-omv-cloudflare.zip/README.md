# Infraestructura Nextcloud + Collabora + Cloudflare Tunnel

Este repositorio contiene todo lo necesario para desplegar tu nube personal en OMV 7 con certificados Let's Encrypt, proxy Cloudflare Tunnel, y edición de documentos online.
