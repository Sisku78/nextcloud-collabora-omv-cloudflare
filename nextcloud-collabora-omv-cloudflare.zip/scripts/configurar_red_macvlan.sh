#!/bin/bash
# Script para crear red macvlan personalizada
