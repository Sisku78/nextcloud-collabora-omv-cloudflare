#!/bin/bash
# Script para emitir certificado wildcard usando DNS-01 y Cloudflare
